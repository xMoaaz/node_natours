const fs = require("fs");
const http = require("http");
const url = require("url");

// const avocadoKnowledge = fs.readFileSync('./txt/input.txt', 'utf-8');
// console.log('---------');

// fs.writeFileSync(`./txt/avocadoKnowledge.txt`, `Our Avocado Knowledge 👉 ${avocadoKnowledge}`);
// console.log('done');

const data = fs.readFileSync(`${__dirname}/dev-data/data.json`, "utf-8");
const dataObj = JSON.parse(data);

const server = http.createServer((req, res) => {
  const pathName = req.url;

  // ROUTING
  if (pathName === "/" || pathName === "/overview") {
    res.end("Overview page");
  } else if (pathName === "/product") {
    res.end("Product page");
  } else if (pathName === "/api") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(data);
  } else {
    res.writeHead(404, {
      "content-type": "text/html",
    });
    res.end("Not Found 404");
  }
});

// Listen on server
server.listen(8000, "127.0.0.1", () => {
  console.log("listening on port 8000...");
});
